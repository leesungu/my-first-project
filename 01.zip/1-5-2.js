for (var k = 0; k < 5; k++){
    console.log(k);
}
